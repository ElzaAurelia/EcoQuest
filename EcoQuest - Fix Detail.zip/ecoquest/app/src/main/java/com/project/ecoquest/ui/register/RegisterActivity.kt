package com.project.ecoquest.ui.register

import android.os.Bundle
import android.util.Patterns
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.navigation.Navigation.findNavController
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.project.ecoquest.R
import com.project.ecoquest.data.FirebaseHelper
import com.project.ecoquest.data.model.UserModel
import com.project.ecoquest.databinding.ActivityRegisterBinding
import kotlinx.coroutines.launch
import java.util.Objects

class RegisterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterBinding
    private lateinit var progressDialog: AlertDialog

    private val firebaseHelper by lazy {
        FirebaseHelper.getInstance()
    }

    private val firebaseAuth: FirebaseAuth by lazy {
        firebaseHelper.auth
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setListeners()
    }


    private fun setListeners() {
        binding.apply {
            btnRegister.setOnClickListener {
                if (isValid()) {
                    showLoadingDialog()

                    val userModel = UserModel()
                    userModel.email = edEmail.text.toString()
                    userModel.password = edPassword.text.toString()
                    userModel.username = edUsername.text.toString()
                    userModel.exp = 0

                    firebaseAuth.createUserWithEmailAndPassword(
                        edEmail.text.toString(),
                        edPassword.text.toString()
                    )
                        .addOnSuccessListener { authResult: AuthResult ->
                            firebaseHelper.userPathDatabase
                                .child(
                                    Objects.requireNonNull<FirebaseUser?>(authResult.user).uid
                                )
                                .setValue(userModel)
                                .addOnSuccessListener {
                                    hideLoadingDialog()
                                    showToast("Successfully Register User! Please Login.")
                                    finish()
                                }.addOnFailureListener { e ->
                                    hideLoadingDialog()
                                    showToast("Error : ${e.localizedMessage}")
                                }
                        }.addOnFailureListener { e: Exception ->
                            hideLoadingDialog()
                            showToast("Error : ${e.localizedMessage}")
                        }
                }
            }

            btnLogin.setOnClickListener { finish() }
        }
    }

    private fun isValid() = if (binding.edUsername.text.isNullOrEmpty()) {
        showToast("Fill username correctly!")
        false
    } else if (binding.edEmail.text.isNullOrEmpty() || !Patterns.EMAIL_ADDRESS.matcher(binding.edEmail.text.toString())
            .matches()
    ) {
        showToast("Fill email correctly!")
        false
    } else if (binding.edPassword.text.isNullOrEmpty()) {
        showToast("Fill password correctly!")
        false
    } else if (binding.edPassword.text.length < 8) {
        showToast("Password must be at least 8 characters!")
        false
    } else {
        true
    }

    private fun showLoadingDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setView(R.layout.progress_dialog)
        builder.setCancelable(false)
        progressDialog = builder.create()
        progressDialog.show()
    }

    private fun hideLoadingDialog() {
        progressDialog.dismiss()
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}