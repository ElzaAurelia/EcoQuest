package com.project.ecoquest.ui.historydetail

import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.project.ecoquest.data.model.History
import com.project.ecoquest.databinding.ActivityHistoryDetailBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryDetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHistoryDetailBinding

    private val history by lazy {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(HISTORY_EXTRA)
        } else {
            intent?.getParcelableExtra(HISTORY_EXTRA, History::class.java)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Log.e("FTEST", "onCreate: masuk", )

        history?.let {
            binding.apply {
                toolbar.setNavigationOnClickListener { finish() }

                ivHistory.setImageBitmap(BitmapFactory.decodeFile(it.image))
                tvTimestamp.text = StringBuilder("Waktu: ${convertTimestampToReadableDate(it.timestamp)}")
            }
        }
    }

    private fun convertTimestampToReadableDate(millis: Long): String {
        val dateFormat = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault())
        return dateFormat.format(Date(millis))
    }

    companion object {
        const val HISTORY_EXTRA = "history_extra"
    }
}