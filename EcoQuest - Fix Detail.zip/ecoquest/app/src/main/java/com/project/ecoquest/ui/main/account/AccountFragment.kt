package com.project.ecoquest.ui.main.account

import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.project.ecoquest.R
import com.project.ecoquest.data.FirebaseHelper
import com.project.ecoquest.databinding.FragmentAccountBinding
import com.project.ecoquest.ui.splash.SplashActivity
import com.project.ecoquest.utils.Constants

class AccountFragment : Fragment() {

    private var _binding: FragmentAccountBinding? = null
    private val binding get() = _binding!!
    private lateinit var progressDialog: AlertDialog


    private val firebaseHelper: FirebaseHelper by lazy {
        FirebaseHelper.getInstance()
    }

    private val userId by lazy {
        Constants.getUserId(requireContext())
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAccountBinding.inflate(inflater, container, false)
        val root: View = binding.root
        val builder = AlertDialog.Builder(requireContext())
        builder.setView(R.layout.progress_dialog)
        builder.setCancelable(false)
        progressDialog = builder.create()
        showLoadingDialog()

        observeUser()
        setListeners()

        return root
    }

    private fun observeUser() {
        firebaseHelper.userPathDatabase.child(userId ?: "").child("username")
            .addValueEventListener(object :
                ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    hideLoadingDialog()
                    val name = snapshot.getValue(String::class.java)
                    binding.tvName.text = name
                }

                override fun onCancelled(error: DatabaseError) {}
            })

        firebaseHelper.userPathDatabase.child(userId ?: "").child("email")
            .addValueEventListener(object :
                ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val email = snapshot.getValue(String::class.java)
                    binding.tvEmail.text = email
                }

                override fun onCancelled(error: DatabaseError) {}
            })
    }

    private fun setListeners() {
        binding.apply {
            btnChangeUsername.setOnClickListener {
                openChangeUsernameDialog()
            }

            btnLogout.setOnClickListener {
                Constants.clearSharedPreferences(requireContext())
                firebaseHelper.auth.signOut()
                requireActivity().finishAffinity()
                startActivity(Intent(requireActivity(), SplashActivity::class.java))
            }
        }
    }

    private fun openChangeUsernameDialog() {
        val inflater = layoutInflater
        val dialogView: View =
            inflater.inflate(R.layout.dialog_change_username, null)

        val dialog = Dialog(requireContext())
        dialog.setContentView(dialogView)
        dialog.setCancelable(true)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)


        val input =
            dialogView.findViewById<EditText>(R.id.ed_username)
        val btnSave = dialogView.findViewById<MaterialButton>(R.id.btn_save)
        val btnCancel =
            dialogView.findViewById<MaterialButton>(R.id.btn_cancel)

        btnSave.setOnClickListener { view: View? ->
            if (input.text.isNullOrEmpty()) {
                showToast("Fill name correctly!")
            } else {
                dialog.dismiss()
                showLoadingDialog()
                firebaseHelper.userPathDatabase.child(userId ?: "")
                    .child("username").setValue(input.text.toString())
                    .addOnSuccessListener {
                        showToast("Successfully Change Username!")
                    }
                    .addOnFailureListener { exception ->
                        hideLoadingDialog()
                        showToast("Error: ${exception.localizedMessage}")
                    }
            }
        }

        btnCancel.setOnClickListener { dialog.dismiss() }

        dialog.show()
    }

    private fun showLoadingDialog() {
        progressDialog.show()
    }

    private fun hideLoadingDialog() {
        progressDialog.dismiss()
    }

    private fun showToast(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }
}