package com.project.ecoquest.ui.main.home

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity.RESULT_OK
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.project.ecoquest.R
import com.project.ecoquest.data.FirebaseHelper
import com.project.ecoquest.data.model.History
import com.project.ecoquest.databinding.FragmentHomeBinding
import com.project.ecoquest.ui.adapter.HistoryAdapter
import com.project.ecoquest.ui.historydetail.HistoryDetailActivity
import com.project.ecoquest.utils.Constants
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class HomeFragment : Fragment() {
    private var nowTime: Long = 0L
    private lateinit var progressDialog: AlertDialog

    private var expTemp = 0

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private lateinit var imagePathLocation: String
    private lateinit var imageStringBase64: String

    private val historyAdapter = HistoryAdapter()

    private val cameraLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (it.resultCode == RESULT_OK) {
            val file = File(imagePathLocation)
            file.let { image ->
                imageStringBase64 = fileToBase64Converter(reduceFileSize(image)) ?: ""

                val history = History()
                history.timestamp = System.currentTimeMillis()
                history.image = imageStringBase64

                showLoadingDialog()
                firebaseHelper.historiesPathDatabase.child(userId ?: "").push().setValue(history)
                    .addOnSuccessListener {
                        firebaseHelper.userPathDatabase.child(userId ?: "").child("exp")
                            .setValue(expTemp + 100)
                            .addOnSuccessListener {
                                showToast("Successfully Finished Today's Quest!")
                            }
                            .addOnFailureListener { error ->
                                hideLoadingDialog()
                                showToast("Error: ${error.message}")
                            }
                    }
                    .addOnFailureListener { error ->
                        hideLoadingDialog()
                        showToast("Error: ${error.message}")
                    }
            }
        }
    }

    private val firebaseHelper: FirebaseHelper by lazy {
        FirebaseHelper.getInstance()
    }

    private val userId by lazy {
        Constants.getUserId(requireContext())
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root
        val builder = AlertDialog.Builder(requireContext())
        builder.setView(R.layout.progress_dialog)
        builder.setCancelable(false)
        progressDialog = builder.create()
        showLoadingDialog()
        nowTime = System.currentTimeMillis()

        observeQuest()
        setListeners()

        return root
    }

    private fun observeQuest() {
        var isHistoryLoaded = false
        var isExpLoaded = false

        fun checkAndHideLoadingDialog() {
            if (isHistoryLoaded && isExpLoaded) {
                hideLoadingDialog()
            }
        }

        firebaseHelper.historiesPathDatabase.child(userId ?: "").orderByChild("timestamp")
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        val historyMutableList = mutableListOf<History>()
                        for (data in snapshot.children) {
                            val history = data.getValue(History::class.java)
                            history?.let { historyMutableList.add(it) }
                        }
                        historyMutableList.reverse()
                        historyAdapter.submitList(historyMutableList)

                        if (historyMutableList.isEmpty()) {
                            binding.rvHistory.isVisible = false
                            binding.tvEmptyHistory.isVisible = true
                        } else {
                            binding.rvHistory.isVisible = true
                            binding.tvEmptyHistory.isVisible = false
                        }

                        setQuestInitializer(historyMutableList.first())
                    } else {
                        binding.rvHistory.isVisible = false
                        binding.tvEmptyHistory.isVisible = true
                        setQuestInitializer(History())
                    }
                    isHistoryLoaded = true
                    checkAndHideLoadingDialog()
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e("HomeFragment", "Database error: ${error.message}")
                    isHistoryLoaded = true
                    checkAndHideLoadingDialog()
                }
            })

        firebaseHelper.userPathDatabase.child(userId ?: "").child("exp")
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val exp = snapshot.getValue(Int::class.java)
                    expTemp = exp ?: 0

                    when (exp) {
                        in 0 until 500 -> {
                            setExpInitializer(1, expTemp)
                        }

                        in 500 until 1000 -> {
                            setExpInitializer(2, expTemp)
                        }

                        else -> {
                            setExpInitializer(3, expTemp)
                        }
                    }
                    isExpLoaded = true
                    checkAndHideLoadingDialog()
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e("HomeFragment", "Database error: ${error.message}")
                    isExpLoaded = true
                    checkAndHideLoadingDialog()
                }
            })
    }

    private fun setQuestInitializer(history: History) {
        if (!isDayChanged(history.timestamp, nowTime)) {
            binding.apply {
                tvEmptyQuest.isVisible = true
                layoutUpload.isVisible = false
            }
        } else {
            binding.apply {
                tvEmptyQuest.isVisible = false
                layoutUpload.isVisible = true
            }
        }
    }

    private fun isDayChanged(absentTimestamp: Long, nowTimestamp: Long): Boolean {
        val lastCalendar = Calendar.getInstance().apply {
            timeInMillis = absentTimestamp
        }
        val currentCalendar = Calendar.getInstance().apply {
            timeInMillis = nowTimestamp
        }
        return currentCalendar.get(Calendar.DAY_OF_YEAR) != lastCalendar.get(Calendar.DAY_OF_YEAR)
    }

    private fun reduceFileSize(file: File): File {
        val bitmap = BitmapFactory.decodeFile(file.path)
        var compressQuality = 100
        var streamLength: Int

        do {
            val bmpStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, compressQuality, bmpStream)
            val bmpPicByteArray = bmpStream.toByteArray()
            streamLength = bmpPicByteArray.size
            compressQuality -= 5
        } while (streamLength > 1000000)

        bitmap.compress(Bitmap.CompressFormat.JPEG, compressQuality, FileOutputStream(file))
        return file
    }

    private fun base64ToTempFile(context: Context, base64String: String): File? {
        return try {
            val decodedBytes = Base64.decode(base64String, Base64.DEFAULT)
            val tempDir = context.cacheDir
            val tempFile = File(tempDir, "image_${System.currentTimeMillis()}.png")
            tempFile.parentFile?.mkdirs()
            FileOutputStream(tempFile).use { outputStream ->
                outputStream.write(decodedBytes)
            }
            tempFile
        } catch (e: IOException) {
            e.printStackTrace()
            null
        }
    }

    private fun setListeners() {
        binding.apply {
            rvHistory.apply {
                historyAdapter.onItemClick = { history ->
                    val temp = base64ToTempFile(requireContext(), history.image)
                    history.image = temp?.absolutePath ?: ""
                    val iHistory = Intent(requireContext(), HistoryDetailActivity::class.java)
                    iHistory.putExtra(HistoryDetailActivity.HISTORY_EXTRA, history)
                    startActivity(iHistory)
                }

                adapter = historyAdapter
                layoutManager = LinearLayoutManager(requireContext())
            }

            btnUpload.setOnClickListener {
                if (checkImagePermission()) {
                    val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                    intent.resolveActivity(requireActivity().packageManager)
                    val storageDir: File? =
                        requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES)
                    val customTempFile = File.createTempFile(
                        SimpleDateFormat(
                            "dd-MMM-yyyy",
                            Locale.US
                        ).format(System.currentTimeMillis()), ".jpg", storageDir
                    )
                    customTempFile.also {
                        imagePathLocation = it.absolutePath
                        intent.putExtra(
                            MediaStore.EXTRA_OUTPUT, FileProvider.getUriForFile(
                                requireContext(),
                                requireActivity().packageName,
                                it
                            )
                        )
                        cameraLauncher.launch(intent)
                    }
                } else {
                    ActivityCompat.requestPermissions(
                        requireActivity(),
                        REQUIRED_CAMERA_PERMISSION,
                        REQUEST_CODE_PERMISSIONS
                    )
                }
            }
        }
    }


    private fun fileToBase64Converter(file: File) = try {
        val byteArray = file.readBytes()
        Base64.encodeToString(byteArray, Base64.DEFAULT)
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }

    private fun checkImagePermission() = REQUIRED_CAMERA_PERMISSION.all {
        ContextCompat.checkSelfPermission(
            requireContext().applicationContext,
            it
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun showLoadingDialog() {
        progressDialog.show()
    }

    private fun hideLoadingDialog() {
        progressDialog.dismiss()
    }

    private fun showToast(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

    private fun setExpInitializer(flag: Int, exp: Int) {
        binding.apply {
            val progress = when (flag) {
                1 -> {
                    (exp.toFloat() / 500F) * 100F
                }

                2 -> {
                    (exp.toFloat() / 1000F) * 100F
                }

                else -> {
                    100F
                }
            }

            progressExp.setProgress(progress.toInt(), true)
            tvChantExp.text = when (flag) {
                1 -> {
                    "Kurang ${500 - exp} poin menuju silver, Semangat!"
                }

                2 -> {
                    "Kurang ${1000 - exp} poin menuju gold, Semangat!"
                }

                else -> {
                    "Selamat kamu telah menjadi Gold!"
                }
            }
            tvCurrentExp.text = StringBuilder("exp: $exp")
            val drawable = when (flag) {
                1 -> {
                    R.drawable.ic_bronze
                }

                2 -> {
                    R.drawable.ic_silver
                }

                else -> {
                    R.drawable.ic_gold
                }
            }

            ivStatusExp.setImageDrawable(ContextCompat.getDrawable(requireContext(), drawable))
        }
    }

    companion object {
        private val REQUIRED_CAMERA_PERMISSION = arrayOf(Manifest.permission.CAMERA)
        private const val REQUEST_CODE_PERMISSIONS = 100
    }
}