package com.project.ecoquest.data.model

data class UserModel(
    var username: String = "",
    var email: String = "",
    var password: String = "",
    var exp: Int = 0
)