package com.project.ecoquest.data.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class History(
    var image: String = "",
    var timestamp: Long = 0L
) : Parcelable