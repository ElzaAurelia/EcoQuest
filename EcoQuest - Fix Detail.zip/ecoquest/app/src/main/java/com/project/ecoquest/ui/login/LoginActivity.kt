package com.project.ecoquest.ui.login

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.project.ecoquest.R
import com.project.ecoquest.data.FirebaseHelper
import com.project.ecoquest.data.model.UserModel
import com.project.ecoquest.databinding.ActivityLoginBinding
import com.project.ecoquest.ui.main.MainActivity
import com.project.ecoquest.ui.register.RegisterActivity
import com.project.ecoquest.utils.Constants

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private lateinit var progressDialog: AlertDialog

    private val firebaseHelper by lazy {
        FirebaseHelper.getInstance()
    }

    private val firebaseAuth: FirebaseAuth by lazy {
        firebaseHelper.auth
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setListeners()
    }

    private fun setListeners() {
        binding.apply {
            btnLogin.setOnClickListener {
                if (isValid()) {
                    showLoadingDialog()

                    firebaseAuth.signInWithEmailAndPassword(
                        edEmail.text.toString(),
                        edPassword.text.toString()
                    )
                        .addOnSuccessListener { authResult: AuthResult ->
                            hideLoadingDialog()
                            firebaseHelper.currentUser = authResult.user
                            Constants.saveUserId(authResult.user?.uid, this@LoginActivity)

                            finishAffinity()
                            startActivity(
                                Intent(
                                    this@LoginActivity,
                                    MainActivity::class.java
                                )
                            )
                        }.addOnFailureListener { e: Exception ->
                            hideLoadingDialog()
                            showToast("Failure: ${e.localizedMessage}")
                        }
                }
            }

            btnRegister.setOnClickListener {
                startActivity(Intent(this@LoginActivity, RegisterActivity::class.java))
            }
        }
    }

    private fun isValid() =
        if (binding.edEmail.text.isNullOrEmpty() || !Patterns.EMAIL_ADDRESS.matcher(binding.edEmail.text.toString())
                .matches()
        ) {
            showToast("Fill email correctly!")
            false
        } else if (binding.edPassword.text.isNullOrEmpty()) {
            showToast("Fill password correctly!")
            false
        } else if (binding.edPassword.text.length < 8) {
            showToast("Password must be at least 8 characters!")
            false
        } else {
            true
        }


    private fun showLoadingDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setView(R.layout.progress_dialog)
        builder.setCancelable(false)
        progressDialog = builder.create()
        progressDialog.show()
    }

    private fun hideLoadingDialog() {
        progressDialog.dismiss()
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}