package com.project.ecoquest.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class FirebaseHelper private constructor() {
    var currentUser: FirebaseUser? = null

    var auth: FirebaseAuth = FirebaseAuth.getInstance()
    var database: FirebaseDatabase = FirebaseDatabase.getInstance()

    val userPathDatabase: DatabaseReference
        get() = database.getReference("Users")

    val historiesPathDatabase: DatabaseReference
        get() = database.getReference("Histories")

    companion object {
        fun getInstance() = FirebaseHelper()
    }
}