package com.project.ecoquest.utils

import android.content.Context

object Constants {

    fun getUserId(context: Context): String? {
        val sharedPreferences =
            context.getSharedPreferences(SHARED_PREFERENCES_NAME, Context.MODE_PRIVATE)
        return sharedPreferences.getString(SHARED_PREFERENCES_USER_ID, null)
    }

    fun saveUserId(userId: String?, context: Context) {
        val sharedPreferences =
            context.getSharedPreferences(SHARED_PREFERENCES_NAME, Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString(SHARED_PREFERENCES_USER_ID, userId)
        editor.apply()
    }

    fun clearSharedPreferences(context: Context) {
        val sharedPreferences =
            context.getSharedPreferences(SHARED_PREFERENCES_NAME, Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.clear()
        editor.apply()
    }

    private const val SHARED_PREFERENCES_NAME = "ecoquest_preferences"
    private const val SHARED_PREFERENCES_USER_ID = "ecoquest_user_id"
}