package com.project.ecoquest.ui.adapter

import android.graphics.BitmapFactory
import android.util.Base64
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.project.ecoquest.data.model.History
import com.project.ecoquest.databinding.ItemHistoryRowBinding
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryAdapter : ListAdapter<History, HistoryAdapter.ViewHolder>(DIFF_CALLBACK) {
    var onItemClick: ((History) -> Unit)? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(
        ItemHistoryRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        getItem(position).let { foodList ->
            foodList?.let { item ->
                with(holder.binding) {
                    ivHistory.setImageBitmap(BitmapFactory.decodeFile(base64ToFile(item.image)?.absolutePath))
                    tvTime.text = convertTimestampToReadableDate(item.timestamp)

                    root.setOnClickListener {
                        onItemClick?.invoke(item)
                    }
                }
            }
        }
    }

    private fun base64ToFile(base64String: String): File? {
        return try {
            val decodedBytes = Base64.decode(base64String, Base64.DEFAULT)
            val file = File.createTempFile("decoded_image", ".jpg")

            FileOutputStream(file).use { fos ->
                fos.write(decodedBytes)
            }

            file
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun convertTimestampToReadableDate(millis: Long): String {
        val dateFormat = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault())
        return dateFormat.format(Date(millis))
    }

    inner class ViewHolder(var binding: ItemHistoryRowBinding) :
        RecyclerView.ViewHolder(binding.root)

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<History>() {
            override fun areItemsTheSame(
                oldStories: History,
                newStories: History
            ): Boolean {
                return oldStories == newStories
            }

            override fun areContentsTheSame(
                oldStories: History,
                newStories: History
            ): Boolean {
                return oldStories.timestamp == newStories.timestamp
            }
        }
    }
}