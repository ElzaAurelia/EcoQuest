package com.project.ecoquest.ui.splash

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.project.ecoquest.databinding.ActivitySplashBinding
import com.project.ecoquest.ui.login.LoginActivity
import com.project.ecoquest.ui.main.MainActivity
import com.project.ecoquest.utils.Constants

class SplashActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySplashBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Handler(Looper.getMainLooper()).postDelayed({
            if (Constants.getUserId(this) != null) {
                val intent = Intent(this, MainActivity::class.java)
                finishAffinity()
                startActivity(intent)
            } else {
                val intent = Intent(this, LoginActivity::class.java)
                finishAffinity()
                startActivity(intent)
            }
        }, 1500L)
    }
}